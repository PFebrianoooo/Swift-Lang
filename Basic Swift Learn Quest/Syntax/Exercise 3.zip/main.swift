var Name = "Siti Dewi Maria"
var City = "Jakarta"
let DateOfBirth = "17-08-1945"
var Adress = "Jl. Swadaya RT 14/008"
var IdNumber = "123-1114-22331"
var Work = "Pelajar / Mahasiswa"
let Gov = "Metro Jaya"

print ("let me introduce myself")
print()
print ("Hii my name is \(Name)")
print ("And i was born in \(City) on \(DateOfBirth)")
print ("My Driver and this is my driver lincense information")
IdNumber.append(" and i get in \(Gov)")
print ("My Id Number \(IdNumber)")
print ("And i work as \(Work)")
print ("And i live in \(Adress)")
