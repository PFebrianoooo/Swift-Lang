/*:
 ### Exercise
 
 1.  Create an array that stores the names of 6 different donuts
 2.  Create a 2nd array that stores the quantity of each of those donuts as an Int
 3.  Remove the last donut in the array and the corresponding last quantity in the quantity array
 4.  Add a new donut name at the beginning of the donut names array and add a new quantity of 0 (zero)  at the beginning of the quantity array
 5.  Remove all elements in both arrays
 
 
 */

// Inititalisation
var Donuts : [String] = ["Strawberry" , "Pineapple" , "Cheese" , "Matcha" , "Tiramissu", "Oreo"]
var Quantity : [Int] = [10 , 20 , 35 , 15 , 25 , 35]
print (Donuts)
print (Quantity)
print ()

// deleting 
print ("Deleting some Donuts and Quantity")
let DeletedDonuts = Donuts.remove(at : 5)
let DeletedQuantity = Quantity.remove(at : 5)
print ("Removes item in donuts name as \(DeletedDonuts)")
print ("Removes of \(DeletedQuantity) pcs \(DeletedDonuts) Donuts")
print ()
// displaying
print (Donuts)
print (Quantity)

// adding
print ()
Donuts.insert("Croissant Taste", at : 0)
Quantity.insert(9 , at : 0)
print ("Add new variant Donuts and Quantity")
// displaying
print (Donuts)
print (Quantity)

// deleting all items and qty
Donuts.remove(at : 0 )
Donuts.remove(at : 1 )
Donuts.remove(at : 2 )
Donuts.remove(at : 3 )
Donuts.remove(at : 4 )
Donuts.remove(at : 5 )

Quantity.remove(at : 0)
Quantity.remove(at : 1)
Quantity.remove(at : 2)
Quantity.remove(at : 3)
Quantity.remove(at : 4)
Quantity.remove(at : 5)

print (Donuts)
print (Quantity)






