// Boolean And Conditional Logic
// Menghitung Nilai siswa
// implementation

// Here is a grade of Otong
var Math = 80
var English = 90
var IndonesianLanguage = 100

let Value = Math  + English + IndonesianLanguage
print ("value all grade of otong is : \(Value)")

let Average = Value / 3
print ("Average value of otong is : \(Average)")

print ()
if Average >= 80 {
  print ("Congratulation otong yuou win as a ")
  print ("First Champion")
}else if Average >= 75 {
    print ("Congratulation otong yuou win as a ")
  print ("Second Champion")
}else if Average >= 65 {
    print ("Congratulation otong yuou win as a ")
  print ("Third Champion")
}else {
  print ("sorry otong you are not be a winner at this comp")
  print ("Come back in next comp and stay learning")
}
