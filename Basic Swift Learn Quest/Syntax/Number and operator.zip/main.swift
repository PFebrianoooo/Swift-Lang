var age = 19 // double
var price = 10000.00 // float

var personage : Double = 20
var itemprice : Float = 11000.00

print ("my friend at \(age) get salary for a week about \(price)")

// perkalian
var panjang = 10
var lebar = 5
print (panjang * lebar)

// pengurangan
var health = 100
var damage = 15
health = health - damage
print (health)

// assginment operator
health -= damage // tambah
health += damage // kurang
health *= damage // kali
health /= damage // bagi
health %= damage // modulo


var position = 70
health += position



