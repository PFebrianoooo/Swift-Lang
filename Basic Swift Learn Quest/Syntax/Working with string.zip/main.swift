
// 2 types for menulis ke tipe data string
// pertama
var FirstName = "Putra"

// kedua
var LastName : String = "Pebriano Nurba"

var Age = 19
var Univ = "University of Muhamadiyah jakarta"
let Prodi = "Informatics Engineering"


print ()
// string concanetation
print ("\(FirstName)" + " " + "\(LastName)")

print()
// string interpolation starts
print ("Welcome \(FirstName)")
print ("Hello my name is \(FirstName) \(LastName) iam \(Age) years old")
// string interpolation ends

Univ.append(" now in third semester")
print ("Now iam study in \(Univ) for \(Prodi)")

