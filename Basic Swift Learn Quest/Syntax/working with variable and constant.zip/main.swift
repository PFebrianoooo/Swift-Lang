// variable which is label by var can hold value like integer double float and boolean and can be accesible anc change the value of the variable

var a = 10
print ("Value of variable a is : \(a)")
a = 20
print (a)

// constant adalah sebuah keyword yanng dapat menyimpan nilai dalam bentuk tipe data dilambangkan dengan let. constant tidak bisa dirubah isinya

let b = 100
/*
b = 200
error: cannot assign to value: 'b' is a 'let' constant
b = 200
^
main.swift:10:1: note: change 'let' to 'var' to make it mutable
let b = 100
^~~
var
*/
print (b)
