/*:
 ### Exercise
 
Consider some basic American traffic signals.
 
   1. Create a string variable named `currentLightColor`
   2. Set the value to "Green", "Yellow", or "Red"
   3. Create if/else conditional logic to print: "The light is 
      X" where X is the value of the light variable
   4. The if /else clause should print the appropriate color

 */

var CurrentLightColor = "Red"

if CurrentLightColor == "Red" {
  print ("The color is \(CurrentLightColor)")
} else if CurrentLightColor == "Yellow"{
  print ("The color is \(CurrentLightColor)")
}else if CurrentLightColor == "Green"{
  print ("The color is \(CurrentLightColor)")
}else {
  print ("Please Rewrite the Value of variable with Red, Yellow or Green")
}
