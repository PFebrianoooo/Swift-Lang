let allowedentry = false
let retinascan = true
let havepfriends = false


// aturan dari or salah satu boleh benar atau keduanya
if retinascan || allowedentry {
  print ("welcome player")
} else {
  print ("access denied")
}

// aturan dari and keduanya harus benar
if allowedentry && retinascan {
  print ("welcome player")
}else {
  print ("one of key is missed")
}

// dijalankan dari depan ke bealkang so dan di eksekusi terlebih dahulu
if allowedentry && havepfriends  || retinascan{
  print ("welcome player")
}else {
  print ("one from three key is missed")
}