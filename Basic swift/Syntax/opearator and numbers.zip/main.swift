
var a = 10 
var b = 15
let area = a * b
let area1 = a - b
let area2 = a + b 
let area3 = b / a
let area4 = a % b
let area5 = pow(a,2)
let area6 = sqrt(pow(a,2))

print ("hasil dari perkalian a dan b adalah : \(area)")
print ("hasil dari pengurangan a dan b adalah : \(area1)")
print ("hasil dari pertambahan a dan b adalah : \(area2)")
print ("hasil dari pembagian a dan b adalah : \(area3)")
print ("hasil dari modulo a dan b adalah : \(area4)")
print ("hasil kuadrat dari bilangan a adalah \(area5)")
print ("hasil akar kuadrat dari bilangan a adalah \(area6)")



var price = 10.99
var qty = 5

let cost = Double(qty) * price
print ("the price of food is : \(cost)")

let first : Double = 25.0
let second : Int = 3
let result = Double(Int(first) * second)
print (result)

var c = 10
var d = 15
let e = pow(c,2)
print (e)
