/*
Pertimbangkan skenario ini: Anda memiliki keranjang belanja dengan 6 item di dalamnya. Total harga semua item yang digabungkan adalah $78,50
  Anda memiliki kupon yang memberi Anda diskon 25% dari total harga.
  Setelah kupon diterapkan, akan dikenakan pajak sebesar 7,75% dari total biaya (biaya setelah kupon).
 
  1. Buat 6 konstanta berbeda yang mewakili harga setiap item
  2. Lakukan operasi penjumlahan untuk mendapatkan harga total keenam item dan menyimpannya secara konstan ($78,50)
  3. Buat konstanta untuk kupon 25%.
  4. Buat konstanta bernama `priceAfterDiscount` dan simpan harga total setelah diskon 25% diterapkan (seharusnya setara dengan $58,87)
  5. Buat konstanta bernama `pajak` yang menyimpan total pajak yang harus dibebankan menggunakan tarif pajak (harus setara dengan $4,56)
  5. Buat konstanta bernama `finalPrice` yang menerapkan tarif pajak 7,75% ke priceAfterDicscount. (harus sama dengan $63,43)
*/

// attributes
let Milk = 20.50
let Bread = 25.60
let Apples = 22.45
let Banana = 12.44
let Orange = 7.55
let Kiwi = 5.66

let Coupon = 0.25
let Tax = 0.0775

// operator
let Price = Milk + Bread + Apples + Banana + Orange + Kiwi

let CostCoupon = Price * Coupon
let priceAfterCoupon = Price - CostCoupon

let CostTax = priceAfterCoupon * Tax
let FinalPrice = priceAfterCoupon + CostTax


print ("====================== Invoice =======================")
print ("=========== Seven Eleven Store Indonesia =============")
print ()
print ("                                   List Of Your Items")
print ("                                    1. Milk   : 20.50")
print ("                                    2. Bread  : 25.60")
print ("                                    3. Apples : 22.45")
print ("                                    4. Banana : 12.44")
print ("                                    5. Orange :  7.55")
print ("                                    6. Kiwi   :  5.66")
print ()
print ("                            Total : \(Price)")
print ("                                     get discount 25%")
print ("                                          Tax : 7.75%")
print ("                  Cost U must Pay : \(FinalPrice)")





